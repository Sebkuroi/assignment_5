
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This class represents GFA test cases for a TwoDimRaggedArrayUtility object.
 * 
 * @author Farnaz Eivazi
 * @version 7/13/2022
 * 
 */
public class TwoDimRaggedArrayUtilityStudentGFATest {
	private double[][] dataSet2 = { { 7, 2, 9, 4 }, { 5 }, { 8, 1, 3 }, { 11, 6, 7, 2 } };
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	@Test
	public void getTotal() {
		assertEquals(65,TwoDimRaggedArrayUtility.getTotal(dataSet2),.001);
	}
	@Test
	public void getAverage() {
		assertEquals(5.416,TwoDimRaggedArrayUtility.getAverage(dataSet2),.001);
	}
	@Test
	public void GetRowTotal() {
		assertEquals(12.0,TwoDimRaggedArrayUtility.getRowTotal(dataSet2,2),.001);
	}
	@Test
	public void getColumnTotal() {
		assertEquals(9.0,TwoDimRaggedArrayUtility.getColumnTotal(dataSet2,1),.001);
	}
	@Test
	public void getHighestInRow() {
		assertEquals(5.0,TwoDimRaggedArrayUtility.getHighestInRow(dataSet2,1),.001);
	}
	@Test
	public void getHighestInRowIndex() {
		assertEquals(2.0,TwoDimRaggedArrayUtility.getHighestInRowIndex(dataSet2,0),.001);
	}
	@Test
	public void getHighestInColumn() {
		assertEquals(11,TwoDimRaggedArrayUtility.getHighestInColumn(dataSet2,0),.001);
	}
	@Test
	public void getHighestInColumnIndex() {
		assertEquals(3.0,TwoDimRaggedArrayUtility.getHighestInColumnIndex(dataSet2,1),.001);
	}
	@Test
	public void getHighestInArray() {
		assertEquals(11.0,TwoDimRaggedArrayUtility.getHighestInArray(dataSet2),.001);
	}
	@Test
	public void getLowestInRow() {
		assertEquals(2,TwoDimRaggedArrayUtility.getLowestInRow(dataSet2,3),.001);
	}
	@Test
	public void getLowestInRowIndex() {
		assertEquals(0,TwoDimRaggedArrayUtility.getLowestInRowIndex(dataSet2,1),.001);
	}
	@Test
	public void getLowestInColumn() {
		assertEquals(1.0,TwoDimRaggedArrayUtility.getLowestInColumn(dataSet2,1),.001);
	}
	@Test
	public void getLowestInColumnIndex() {
		assertEquals(2.0,TwoDimRaggedArrayUtility.getLowestInColumnIndex(dataSet2,1),.001);
	}
	@Test
	public void getLowestInArray() {
		assertEquals(1.0,TwoDimRaggedArrayUtility.getLowestInArray(dataSet2),.001);
	}
}
