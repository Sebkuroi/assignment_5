/*
 * Class: CMSC203 
 * Instructor:Grigoriy Grinberg
 * Description: (more or less building a property)
 * Due: 03/3/2023
 * Platform/compiler:eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Sebastian Black
*/
public class HolidayBonus {
	public static double[] calculateHolidayBonus(double[][] Sale) {
		double high = 5000, low = 1000, other=2000;
		double bonus[] = new double[Sale.length];

		for (int row = 0; row < Sale.length; row++) 
		{
			for (int column = 0; column < Sale[row].length; column++) 
			{
			if (Sale[row][column] > 0)
			{
					if (Sale[row][column] == TwoDimRaggedArrayUtility.getHighestInColumn(Sale, column)) 
					{
						bonus[row] = bonus[row] + high;
					} 
					else if (Sale[row][column] == TwoDimRaggedArrayUtility.getLowestInColumn(Sale, column)) 
					{
						bonus[row] = bonus[row] + low;
					} 
					else 
					{
						bonus[row] = bonus[row] + other;
					}

				}
			}
		}	
		return bonus;
	}

	public static double calculateTotalHolidayBonus(double[][] Sale)
	{
		double[] bonus = calculateHolidayBonus(Sale);
		double Toatlbonus = 0;
		for (int bonusnumber = 0; bonusnumber < bonus.length; bonusnumber++) 
		{
			Toatlbonus = Toatlbonus + bonus[bonusnumber];
		}

		return Toatlbonus;
	}
}