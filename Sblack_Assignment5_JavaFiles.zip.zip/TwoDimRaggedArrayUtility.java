import java.io.PrintWriter;
import java.util.Scanner;

public class TwoDimRaggedArrayUtility
{
	
	public static double[][] readFile(java.io.File file) throws java.io.FileNotFoundException 
	{
		
		Scanner keyboard = new Scanner(file);
		String[][] temp = new String[100][];
		int rows = 0;

		while (keyboard.hasNext())
		{
			temp[rows] = keyboard.nextLine().split(" ");
			rows++;
		}
		keyboard.close();
		
		double[][] sales = new double[rows][];
		
		for (int row=0; row<rows; row++) 
		{
			sales[row]= new double[temp[row].length];
			int columns = temp[row].length;
			sales[row] = new double[columns];
			for (int column=0; column<columns; column++)  
			{
				sales[row][column] = Double.parseDouble(temp[row][column]);
			}
		}
		
		return sales;
	}
	
	public static void writeToFile(double[][] data, java.io.File outputFile) throws java.io.FileNotFoundException
	{
		PrintWriter outFile = new PrintWriter(outputFile);
		
		for (int row=0; row<data.length; row++) 
		{
			String space = "";
			for (int column=0; column<data[row].length; column++)
			{
				space = space + data[row][column] + " ";
			}
			outFile.println(space);
		}
		outFile.close();

	}
	
	public static double getTotal(double[][] data) 
	{
		double Total = 0.0;
		
		for (int row=0; row<data.length; row++) 
		{
			for (int column=0; column<data[row].length; column++) 
			{
				Total = Total + data[row][column];
			}
		}
		return Total;
	}
	
	public static double getAverage(double[][] data)
	{
		double Total = 0.0;
		int numberofsales = 0;
		
		for (int row=0; row<data.length; row++) 
		{
			for (int column=0; column<data[row].length; column++) 
			{
				Total = Total + data[row][column];
				numberofsales++;
			}
		}
		return Total/numberofsales;
	}

	public static double getRowTotal(double[][] data, int row) 
	{
		double rowTotal = 0.0;
		
		for (int column=0; column<data[row].length; column++) 
		{
			rowTotal = rowTotal + data[row][column];
		}
		
		return rowTotal;
	}

	public static double getColumnTotal(double[][] data, int col)
{
		double columntotal = 0.0;
		
		for (int row=0; row<data.length; row++)
		{
			if (col<data[row].length) 
			{
				columntotal = columntotal + data[row][col];
			}
		}
		
		return columntotal;
	}

	public static double getHighestInRow(double[][] data, int row)
	{
		double highestvalue = -9999999;
		
		for (int column=0; column<data[row].length; column++) 
		{
			if (data[row][column] > highestvalue) 
			{
				highestvalue =  data[row][column];
			}
		}
		
		return highestvalue;
	}
	
	public static int getHighestInRowIndex(double[][] data, int row) 
	{
		double highestvalue = -9999999;
		int highestvalueinIDX = 0;
		
		for (int column=0; column<data[row].length; column++) 
		{
			if (data[row][column] > highestvalue) 
			{
				highestvalue =  data[row][column];
				highestvalueinIDX = column;
			}
		}
		
		return highestvalueinIDX;
	}
	
	public static double getHighestInColumn(double[][] data, int col) 
	{
		double highestvalue = -9999999;
		
		for (int row=0; row<data.length; row++) 
		{
			if (col<data[row].length) 
			{
				if (data[row][col] > highestvalue) 
				{
					highestvalue = data[row][col];
				}
			}
		}
		
		return highestvalue;
	}

	public static int getHighestInColumnIndex(double[][] data, int col) 
	{
		double highestvalue =-9999999;
		int highestvalueIdx = 0;
		
		for (int row=0; row<data.length; row++) 
		{
			if (col<data[row].length) 
			{
				if (data[row][col] > highestvalue) 
				{
					highestvalue = data[row][col];
					highestvalueIdx = row;
				}
			}
		}
		
		return highestvalueIdx;
	}
	
	public static double getHighestInArray(double[][] data) 
	{
		double highestvalue =-9999999;
		
		for (int row=0; row<data.length; row++) 
		{
			for (int col=0; col<data[row].length; col++) 
			{
				if (data[row][col] > highestvalue) 
				{
					highestvalue = data[row][col];
				}
			}
		}
		
		return highestvalue;
	}

	public static double getLowestInRow(double[][] data, int row) 
	{
		double lowestvalue =  9999999;
		for (int column=0; column<data[row].length; column++) 
		{
			if (data[row][column] < lowestvalue) 
			{
				lowestvalue =  data[row][column];
			}
		}
		
		return lowestvalue;
	}
	
	public static int getLowestInRowIndex(double[][] data, int row) 
	{
		double lowestvalue =  9999999;
		int lowestvalueinIDX = 0;
		
		for (int column=0; column<data[row].length; column++) 
		{
			if (data[row][column] < lowestvalue)
			{
				lowestvalue =  data[row][column];
				lowestvalueinIDX = column;
			}
		}
		
		return lowestvalueinIDX;
	}

	public static double getLowestInColumn(double[][] data, int col) 
	{
		double lowestvalue =  9999999;
		
		for (int row=0; row<data.length; row++) 
		{
			if (col<data[row].length) 
			{
				if (data[row][col] < lowestvalue) 
				{
					lowestvalue = data[row][col];
				}
			}
		}
		
		return lowestvalue;
	}

	public static int getLowestInColumnIndex(double[][] data, int col) 
	{
		double lowestvalue =  9999999;
		int lowestvalueinIDX = 0;
		
		for (int row=0; row<data.length; row++) 
		{
			if (col<data[row].length) 
			{
				if (data[row][col] < lowestvalue) 
				{
					lowestvalue = data[row][col];
					lowestvalueinIDX = row;
				}
			}
		}
		
		return lowestvalueinIDX;
	}

	public static double getLowestInArray(double[][] data)
	{
		double lowestvalue =  9999999;
		for (int row=0; row<data.length; row++)
		{
			for (int col=0; col<data[row].length; col++)
			{
				if (data[row][col] < lowestvalue)
				{
					lowestvalue = data[row][col];
				}
			}
		}
		
		return lowestvalue;
	}
}